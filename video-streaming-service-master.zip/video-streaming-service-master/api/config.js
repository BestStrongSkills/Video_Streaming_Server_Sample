exports.mongodbUrl = 'mongodb://localhost:27017/stream'
exports.dbName = 'stream';