import React,{Component} from 'react'
import styled  from 'styled-components'

const HomeWrapper = styled.div `

  

`
export default class Home extends Component{

    render(){

        return <HomeWrapper>
            <h1>Welcome to Camera App.</h1>
        </HomeWrapper>
    }
}