export const bodyColor = 'rgba(0, 0 ,0 ,0.7)';
export const headerHeight = 50;
export const primaryColor = '#2ecc71';
export const dangerColor = '#e67e22';
export const borderColor = 'rgba(0, 0, 0, 0.07)';
export const containerMaxWidth = 1200;