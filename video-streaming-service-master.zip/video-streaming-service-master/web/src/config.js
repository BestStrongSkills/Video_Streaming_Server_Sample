const isProduction = false;

export const api = isProduction ? 'http://tabvn.com' : ' http://localhost:3001';
